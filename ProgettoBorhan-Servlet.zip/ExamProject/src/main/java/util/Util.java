package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Properties;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

//For crypt 
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class Util {
	public static final String USER = "root";
	public static final String PWD = "#Progetto10";
	public static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver";
	public static final String DB_NAME = "mail_db";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/" + DB_NAME;
		
	public static final Connection initDbConnection() {
		try {
			Class.forName(DRIVER_CLASS);
			
		    Properties connectionProps = new Properties();
		    connectionProps.put("user", USER);
		    connectionProps.put("password", PWD);
	
	        return DriverManager.getConnection(DB_URL, connectionProps);
		    
		    //System.out.println("User \"" + USER + "\" connected to database.");
    	
    	} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static void deleteCookie(HttpServletRequest request, HttpServletResponse response) {
	    //Get all cookies from the request and remove the one called "X-CSRF"
	    Cookie[] cookies = request.getCookies();
	    if (cookies == null) cookies = new Cookie[]{};
	    Arrays.stream(cookies)
	        .filter(cookie -> cookie.getName().equals("X-CSRF"))
	        .forEach(cookie -> {
	            cookie.setValue("");
	            cookie.setMaxAge(0);
	            response.addCookie(cookie);
	        });
	    
	}
	
	public static String cryptPassword(String password) {
		
        String passwordToHash = "password";
        String passwordHashed = null;

        try 
        {
        	// Create MessageDigest instance for MD5
        	MessageDigest md = MessageDigest.getInstance("MD5");

        	// Add password bytes to digest
        	md.update(passwordToHash.getBytes());

        	// Get the hash's bytes
        	byte[] bytes = md.digest();

        	// This bytes[] has bytes in decimal format. Convert it to hexadecimal format
        	StringBuilder sb = new StringBuilder();
        	for (int i = 0; i < bytes.length; i++) {
        		sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
        	}

        	// Get complete hashed password in hex format
        	passwordHashed = sb.toString();
        	
        } catch (NoSuchAlgorithmException e) {
        	e.printStackTrace();
        }
        
        System.out.println(passwordHashed);
        
		return passwordHashed;
	}
	
}
