package servlet;

import java.io.IOException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import util.Util;


@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
	private static Connection conn;
	

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LogoutServlet() {
		super();
	}

	public void init() throws ServletException {
		conn = Util.initDbConnection();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Util.deleteCookie(request, response);  //cancellazione cookie
		request.getSession().invalidate();  //invalidazione della sessione
		request.getRequestDispatcher("/login.html").forward(request,response); //redirezione alla pagina di login
	}
	
	
}