package servlet;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Random;

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Array;

import java.security.SecureRandom;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import util.Util;

/**
 * Servlet implementation class HelloWorldServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Connection conn;
	

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
	}

	public void init() throws ServletException {
		conn = Util.initDbConnection();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		String email = request.getParameter("email");
		String pwd = request.getParameter("password");
		

		try{
			

			PreparedStatement preparedSt = conn.prepareStatement("SELECT * FROM user WHERE email = ? AND password = ?");

			preparedSt.setString(0, email);
			preparedSt.setString(1, pwd);


			ResultSet sqlRes = preparedSt.executeQuery();
		
			if(sqlRes.next()){

				request.setAttribute("email", sqlRes.getString(3));
				request.setAttribute("password", sqlRes.getString(4));
				
				System.out.println("Login succeeded!");
				request.setAttribute("content", "");
				request.getRequestDispatcher("home.jsp").forward(request, response);

			}else {
				System.out.println("Login failed!");
				request.getRequestDispatcher("login.html").forward(request, response);
			}

		}catch (SQLException e) {
			e.printStackTrace();
			request.getRequestDispatcher("register.html").forward(request, response);
		}
	}
	
	
	
	//CSRF Token Generation
	public static void setCsrfToken(HttpServletRequest request, HttpServletResponse response) {
	    //Generate a random token
		String token = new SecureRandom().toString();

	    
		HttpSession session =request.getSession(true);
		session.setAttribute("X-CSRF", token);
		
		
	    
		Cookie xcsrfCookie = new Cookie("X-CSR", token);
		response.addCookie(xcsrfCookie);
		
	}


	public void checkCsrf(HttpServletRequest request) {
	    //read the cookie content
	    String cookieContent = Arrays.stream(request.getCookies())
	            .filter(cookie -> cookie.getName().equals("X-CSRF"))
	            .map(Cookie::getValue)
	            .findFirst().orElse("");
	    
	    
	    HttpSession session = request.getSession();
	    
	    try {
	    	String token = session.getAttribute("X-CSRF").toString();
	    	if(!token.equals(cookieContent)) {
	    		throw new Exception("Invalid X-CSRF");
	    	}
	    	
	    }catch(Exception error) {
	    	System.out.println("Token required");
	    }

	}
}
