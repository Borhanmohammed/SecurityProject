package servlet;

import jakarta.servlet.http.HttpServlet;
import java.io.IOException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.Util;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static Connection conn;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
    }
    
    public void init() throws ServletException {
    	conn = Util.initDbConnection();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		// The replacement escapes apostrophe special character in order to store it in SQL
		String name = request.getParameter("name").replace("'", "''");
		String surname = request.getParameter("surname").replace("'", "''");
		String email = request.getParameter("email").replace("'", "''");
		String pwd = request.getParameter("password").replace("'", "''");
		
		String securePass = "";
		
		//Crypt password
		
		try {
			
			securePass = Crypt.password(pwd);
			//boolean matched = CryptVerify.verify(pass, securePass); //Non riesco a capire il meccanismo per farlo funzionare.
			
		}catch(Exception e) {
			e.printStackTrace();
			request.getRequestDispatcher("login.html").forward(request, response);
		}
		

		try{
			PreparedStatement preparedSt = conn.prepareStatement("INSERT INTO user ( name, surname, email, password ) VALUES( ?, ?, ?, ? )");
			preparedSt.setString(1, name);
			preparedSt.setString(2, surname);
			preparedSt.setString(3, email);
			preparedSt.setString(4, securePass);
			preparedSt.executeUpdate();
			
			
			request.setAttribute("email", email);
			request.setAttribute("password", pwd);
			
			System.out.println("Registration succeeded!");
			request.getRequestDispatcher("login.html").forward(request, response);

		} catch (SQLException e) {
			e.printStackTrace();
			request.getRequestDispatcher("register.html").forward(request, response);
		}
	}

}